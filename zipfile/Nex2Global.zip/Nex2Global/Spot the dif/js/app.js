function saveUserData(userData){
    $.post('php/userData.php',
     {oauth_provider:'facebook',
     userData: JSON.stringify(userData)}, 
     function(data)
     { return true; });

}
var tm=1000;
$(document).ready(function() {



   $('#myModal').modal({backdrop: 'static', keyboard: false}) 
   $('#myModal').modal('show');
 
$("img").click(function(){
    if($("#first").is(":visible")){
    $("#first").hide();
    } 
  else if($("#second").is(":visible")){
    $("#second").hide();
    } 
 else if($("#third").is(":visible")){
    $("#third").hide();
    alert("Game over!");
    } 
});



    // When clicked, show difference
	$('#transparentmap AREA').click(function() { 
	var theDifference = '#'+$(this).attr('id')+'-diff';
	$(theDifference).css('display', 'inline');
    $(theDifference).data('clicked', true);


	
	// When all differences selected/clicked, show email submission form
	if($('#leaf-diff').data('clicked') && $('#petal-diff').data('clicked') && $('#light-diff').data('clicked') && $('#nolight-diff').data('clicked') && $('#sauce-diff').data('clicked')) {

		$('#form_container').css('display', 'inline');
		tm='d';
	}




	});


});


function call(){


               	function progress(timeleft, timetotal, $element) {
    var progressBarWidth = timeleft * $element.width() / timetotal;
    $element.find('div').animate({ width: progressBarWidth }, 
	timeleft === timetotal ? 0 : 1000, 'linear');

    if(timeleft >= '0') {
      var timer= setTimeout(function() {
            progress(timeleft - 1, timetotal, $element);
			console.log(timeleft+":"+timetotal);
        }, tm);
    }
	else{
		alert('Game Over!');		
		
	}

};

progress(30, 30, $('#progressBar'));
                

}



window.fbAsyncInit = function() {
    // FB JavaScript SDK configuration and setup
    FB.init({
      appId      : '1761769924086338', // FB App ID
      cookie     : true,  // enable cookies to allow the server to access the session
      xfbml      : true,  // parse social plugins on this page
      version    : 'v2.8' // use graph api version 2.8
    });
    
    // Check whether the user already logged in
	FB.getLoginStatus(function(response) {
		if (response.status === 'connected') {
			//display user data
			getFbUserData();
			 
		}
	});
};

// Load the JavaScript SDK asynchronously
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

// Facebook login with JavaScript SDK
function fbLogin() {
    FB.login(function (response) {
        if (response.authResponse) {
            // Get and display the user profile data
            getFbUserData();

        //   document.getElementById("wrapper").style.visibility = "visible";
		//     document.getElementById("userData").style.visibility = "hidden";
		// 	  document.getElementById("status").style.visibility = "hidden";
        } else {
            document.getElementById('status').innerHTML = 'User cancelled login or did not fully authorize.';
        }
    }, {scope: 'email'});
}

// Fetch the user profile data from facebook
function getFbUserData(){
    FB.api('/me', {locale: 'en_US', fields: 'id,friendlists,first_name,last_name,email,link,gender,locale,picture'},
    function (response) {
        // document.getElementById('fbLink').setAttribute("onclick","fbLogout()");
        // document.getElementById('fbLink').innerHTML = 'Logout from Facebook';

        // document.getElementById('status').innerHTML = 'Thanks for logging in, ' + response.first_name + '!';
        // document.getElementById('userData').innerHTML = '<p><b>FB ID:</b> '+response.id+'</p><p><b>Name:</b> '+response.first_name+' '+response.last_name+'</p><p><b>Email:</b> '+response.email+'</p><p><b>Gender:</b> '+response.gender+'</p><p><b>Locale:</b> '+response.locale+'</p><p><b>Picture:</b> <img src="'+response.picture.data.url+'"/></p><p><b>FB Profile:</b> <a target="_blank" href="'+response.link+'">click to view profile</a></p>';

     saveUserData(response);
     $('#myModal').modal('hide');
     call();

    });
}

// Logout from facebook
// function fbLogout() {
//     FB.logout(function() {
//         document.getElementById('fbLink').setAttribute("onclick","fbLogin()");
//         document.getElementById('fbLink').innerHTML = '<img src="fblogin.png"/>';
//         document.getElementById('userData').innerHTML = '';
//         document.getElementById('status').innerHTML = 'You have successfully logout from Facebook.';
//     });
// }






